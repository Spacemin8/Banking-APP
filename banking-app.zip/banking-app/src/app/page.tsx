import React from "react";
import Deposit from "./components/Deposit";
import Withdraw from "./components/Withdraw";
import Transfer from "./components/Transfer";
import AccountStatement from "./components/AccountStatement";
import AccountPage from "./components/AccountPage";
import Account from "./components/Account";

export default function Home() {
  return (
    <div>
     <Account />
    </div>
  );
}
